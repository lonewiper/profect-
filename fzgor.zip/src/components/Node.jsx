  
import React from "react";
function Node(){
return (
   <div className = "note"> 
     <h1>javascript and React.js</h1>
     <p>this was an amazing boot camp taken up by
      Sharura singh.We cover everthing from Sharura singhincluind javascript
      and React .js,HTML.
      </p>
   </div>
);

}
export default Node;
